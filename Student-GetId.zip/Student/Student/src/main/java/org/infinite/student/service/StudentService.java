package org.infinite.student.service;

import java.util.List;
import java.util.Optional;

import org.infinite.student.model.Student;
import org.infinite.student.repository.StudentRepository;
import org.infinite.student.response.StudentResponse;
import org.infinite.student.response.SubjectResponse;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class StudentService {
	
	@Autowired
	private StudentRepository stdRepo;
	
	@Autowired
    private ModelMapper mapper;
	
	@Autowired
	private RestTemplate restTemplate;
 
    public StudentResponse getStudentById(Long id) {
        Optional<Student> student = stdRepo.findById(id);
        StudentResponse studentResponse = mapper.map(student, StudentResponse.class);
        
        SubjectResponse subjectResponse=restTemplate.getForObject("http://localhost:8001/subject/{id}", SubjectResponse.class,id);
        studentResponse.setSubjectresponse(subjectResponse);
        
        return studentResponse;
    }
    public StudentResponse getStudents() {
    	 
        List<Student> students = stdRepo.findAll();
        StudentResponse studentResponse = mapper.map(students, StudentResponse.class);
 
        SubjectResponse subjectResponse = restTemplate.getForObject("http://localhost:8081/subjects", SubjectResponse.class);
        studentResponse.setSubjectresponse(subjectResponse);
 
        return studentResponse;
    }

}
