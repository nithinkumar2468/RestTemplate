package com.infinite.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductExApplicationTests {

	@Test
	void contextLoads() {
	}

}
