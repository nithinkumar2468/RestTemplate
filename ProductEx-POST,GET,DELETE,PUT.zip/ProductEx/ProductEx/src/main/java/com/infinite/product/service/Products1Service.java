package com.infinite.product.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


import com.infinite.product.exception.ProductNotFoundException;
import com.infinite.product.model.Products;
import com.infinite.product.model.Products1;
import com.infinite.product.model.Products2;
import com.infinite.product.repository.Products1Repository;

import lombok.val;

@Service
public class Products1Service {
	@Autowired
	private Products1Repository prodRepo;
	
	@Autowired
	private RestTemplate restTemplate;
	

	public Products1 addProduct1(Products1 product1) {
		// TODO Auto-generated method stub
		return prodRepo.save(product1);
	}

	public List<List<? extends Object>> getallproducts() {
		// TODO Auto-generated method stub
		
		HttpHeaders headers=new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> httpEntity=new HttpEntity<String>(headers);
		List<Products2> getProducts2=restTemplate.getForObject("http://localhost:8008/products2",ArrayList.class);
		
		List<Products1> getProducts1=prodRepo.findAll();
		
		List<List<? extends Object>> products= Arrays.asList(getProducts1,getProducts2);
		return products;
	}
	
	public Optional<Products1> getproductbyid(Long pid) {
		// TODO Auto-generated method stub
		return prodRepo.findById(pid);
	}

	/*public Optional<Products1> updateproductbyid(Products1 product, Long pid) {
		// TODO Auto-generated method stub
		return prodRepo.findById(pid).map(prod->{
			prod.setName(product.getName());
			prod.setRating(product.getRating());
			prod.setPrice(product.getPrice());
			return prodRepo.save(prod);
		});
	}*/
	/*public void updateproductid(Products1 product, Long pid){
		HttpHeaders headers=new HttpHeaders();
		HttpEntity<Products2> entity=new HttpEntity<Products2>(headers);
		ResponseEntity<String> response=restTemplate.exchange("http://localhost:8008/product2/{id}",HttpMethod.PUT,entity,String.class,pid);
		System.out.println("Updated Succesfully");
	}*/
	
	public void updateproductid(Products2 product, Long pid){
		/*Products2 products2=new Products2(1L,2L,"Realme C5","5",1000L);*/
		HttpHeaders headers=new HttpHeaders();
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<Products2> entity=new HttpEntity<Products2>(headers);
		restTemplate.put("http://localhost:8008/product2/{id}",product,pid);
	}
	

	public void deleteproductbyid(Long pid) {
		// TODO Auto-generated method stub
		if(prodRepo.findById(pid) != null&&prodRepo.findById(pid).isPresent()){
			System.out.println(prodRepo.findById(pid).isPresent());
			prodRepo.deleteById(pid);
		}
		else{
			restTemplate.delete("http://localhost:8008/product2/{id}", pid);
		}
	}
}
