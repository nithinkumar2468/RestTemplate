package com.infinite.product.dto;

import java.util.List;

import com.infinite.product.model.Products1;
import com.infinite.product.model.Products2;

import lombok.Data;

@Data
public class Product1DTO {
	private Products1 products1;
	
	private List<Products2> products2;

	public Products1 getProducts1() {
		return products1;
	}

	public void setProducts1(Products1 products1) {
		this.products1 = products1;
	}

	public List<Products2> getProducts2() {
		return products2;
	}

	public void setProducts2(List<Products2> products2) {
		this.products2 = products2;
	}

}
