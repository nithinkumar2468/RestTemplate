package com.infinite.product.client;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.infinite.product.model.Products1;
import com.infinite.product.model.Products2;

@Component
public class Products2Client {

	@Autowired
	private RestTemplate restTemplate;

	public void saveProducts2(List<Products2> products2, Long pid) {
		products2.stream().forEach(pro2 -> {
			pro2.setPid(pid);
			HttpHeaders httpHeaders = new HttpHeaders();
			httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
			HttpEntity<Products2> httpEntity = new HttpEntity<Products2>(pro2, httpHeaders);
			restTemplate.exchange("http://localhost:8008/product2", HttpMethod.POST, httpEntity, String.class);
		});
	}
	
	
}
