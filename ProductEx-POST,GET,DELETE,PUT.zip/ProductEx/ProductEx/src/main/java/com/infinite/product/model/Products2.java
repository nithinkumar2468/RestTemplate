package com.infinite.product.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Products2 {
	@Id
	@GeneratedValue
	private Long pid2;
	
	private Long pid;
	
	private String p_name;
	
	private String p_rating;
	
	private Long p_price;

	public Long getPid2() {
		return pid2;
	}

	public void setPid2(Long pid2) {
		this.pid2 = pid2;
	}

	public Long getPid() {
		return pid;
	}

	public void setPid(Long pid) {
		this.pid = pid;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getP_rating() {
		return p_rating;
	}

	public void setP_rating(String p_rating) {
		this.p_rating = p_rating;
	}

	public Long getP_price() {
		return p_price;
	}

	public void setP_price(Long p_price) {
		this.p_price = p_price;
	}

	public Products2(Long pid2, Long pid, String p_name, String p_rating, Long p_price) {
		super();
		this.pid2 = pid2;
		this.pid = pid;
		this.p_name = p_name;
		this.p_rating = p_rating;
		this.p_price = p_price;
	}

	public Products2() {
		super();
	}


}
