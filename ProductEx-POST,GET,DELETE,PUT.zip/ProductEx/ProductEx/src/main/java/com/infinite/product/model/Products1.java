package com.infinite.product.model;

import java.util.ArrayList;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class Products1 {
	@Id
	@GeneratedValue
	private Long pid;
	
	private String name;
	
	private String rating;
	
	private Long price;

	public Long getPid() {
		return pid;
	}

	public void setPid(Long pid) {
		this.pid = pid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public Long getPrice() {
		return price;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	public Products1(Long pid, String name, String rating, Long price) {
		super();
		this.pid = pid;
		this.name = name;
		this.rating = rating;
		this.price = price;
	}

	public Products1() {
		super();
	}

	
}
