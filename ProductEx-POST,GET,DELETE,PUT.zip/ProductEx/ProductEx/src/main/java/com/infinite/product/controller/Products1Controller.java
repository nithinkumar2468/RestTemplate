package com.infinite.product.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infinite.product.client.Products2Client;
import com.infinite.product.dto.Product1DTO;
import com.infinite.product.model.Products;
import com.infinite.product.model.Products1;
import com.infinite.product.model.Products2;
import com.infinite.product.service.Products1Service;

@RestController
public class Products1Controller {
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private Products1Service prodService;
	
	@Autowired
	private Products2Client product2client;

	/*@PostMapping("/product1")
	public Products1 CreateProduct(@RequestBody Products1 product1) {
		return prodService.addProduct1(product1);
	}*/
	@PostMapping("product1")
	public ResponseEntity<String> CreateProduct(@RequestBody Product1DTO product1DTO){
		Products1 saveproducts1=prodService.addProduct1(product1DTO.getProducts1());
		if(saveproducts1!=null&&saveproducts1.getPid()>0)
		{
			product2client.saveProducts2(product1DTO.getProducts2(),saveproducts1.getPid());
		}
		return new ResponseEntity<>("Product added Succesfully",HttpStatus.CREATED);
	}

	/*@GetMapping("/products1")
	List<Products1> GetAllProducts1() {
		return prodService.getallproducts();
	}*/
	/*@GetMapping("/products1")
	public ResponseEntity<List<Products1>> GetAllProducts1(){
		List<Products1> saveproducts1=prodService.getallproducts();
		Object[] s=saveproducts1.toArray();
		ArrayList<String> products2=restTemplate.getForObject("http://localhost:8008/products2",ArrayList.class);
		System.out.println(products2);
		System.out.println(s);
		List<String> li=new ArrayList<String>();
		li.add(saveproducts1);
		return new ResponseEntity<>(saveproducts1,HttpStatus.CREATED);
	}*/
	
	@GetMapping("/products1")
	public ResponseEntity<List<List<? extends Object>>> GetAllProducts1(){
		List<List<? extends Object>> getProducts1=prodService.getallproducts();
		return new ResponseEntity<>(getProducts1,HttpStatus.CREATED);
	}
	
	/*@GetMapping("/products1")
    private ResponseEntity<StudentResponse> getStudentDetails(@PathVariable("id") Long id) {
		StudentResponse student = stdService.getStudentById(id);
        return ResponseEntity.status(HttpStatus.OK).body(student);
    }*/
	

	@GetMapping("/product1/{pid}")
	public Optional<Products1> GetProduct1byId(@PathVariable Long pid) {
		return prodService.getproductbyid(pid);
	}

	/*@PutMapping("/product1/{pid}")
	public Optional<Products1> UpdateProduct1byId(@RequestBody Products1 product, @PathVariable Long pid) {
		return prodService.updateproductbyid(product, pid);
	}*/
	@PutMapping("/product1/{pid}")
	public ResponseEntity<String> UpdateProduct1byId(@RequestBody Products2 product, @PathVariable Long pid) {
		prodService.updateproductid(product, pid);
		
		return new ResponseEntity<String>("Updated Successfully", HttpStatus.OK);
	}

	@DeleteMapping("/product1/{pid}")
	String DeleteProduct1byId(@PathVariable Long pid) {
		prodService.deleteproductbyid(pid);
		return "Deleted Successfully";
	}
}
