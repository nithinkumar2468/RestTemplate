package com.infinite.product.model;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Products {
	@Id
	@GeneratedValue
	private Long id;
	
	private String name;
	
	private String rating;
	
	private Long price;
	
	private Products1 products1;
	
	private Products2 products2;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public Long getPrice() {
		return price;
	}

	public void setPrice(Long price) {
		this.price = price;
	}

	public Products1 getProducts1() {
		return products1;
	}

	public void setProducts1(Products1 products1) {
		this.products1 = products1;
	}

	public Products2 getProducts2() {
		return products2;
	}

	public void setProducts2(Products2 products2) {
		this.products2 = products2;
	}
	
	
	

}
