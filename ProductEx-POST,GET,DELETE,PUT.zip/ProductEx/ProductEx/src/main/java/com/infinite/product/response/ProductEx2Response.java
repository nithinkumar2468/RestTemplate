package com.infinite.product.response;

public class ProductEx2Response {
	private Long pid2;

	private String p_name;

	private String p_rating;

	private Long p_price;

	public Long getPid2() {
		return pid2;
	}

	public void setPid2(Long pid2) {
		this.pid2 = pid2;
	}

	public String getP_name() {
		return p_name;
	}

	public void setP_name(String p_name) {
		this.p_name = p_name;
	}

	public String getP_rating() {
		return p_rating;
	}

	public void setP_rating(String p_rating) {
		this.p_rating = p_rating;
	}

	public Long getP_price() {
		return p_price;
	}

	public void setP_price(Long p_price) {
		this.p_price = p_price;
	}
	

}
