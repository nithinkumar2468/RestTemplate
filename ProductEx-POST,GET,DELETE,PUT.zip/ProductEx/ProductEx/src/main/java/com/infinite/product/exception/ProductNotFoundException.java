package com.infinite.product.exception;

public class ProductNotFoundException extends RuntimeException{
	public ProductNotFoundException(Long pid){
		super("Could not found the Product with id "+ pid);
	}

}
