package org.infinite.subject.repository;

import java.util.Optional;

import org.infinite.subject.model.Subject;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface SubjectRepository extends JpaRepository<Subject,Long>{

	
	@Query(
	        nativeQuery = true,
	        value
	        = "SELECT ea.id, ea.city, ea.state FROM tutorialdb.subject ea join tutorialdb.student e on e.id = ea.id where ea.id=:id")
	       Optional<Subject> findSubjectByStudentId(@Param("id") Long id);
	}

