package org.infinite.subject.service;

import java.util.Optional;

import org.infinite.subject.model.Subject;
import org.infinite.subject.repository.SubjectRepository;
import org.infinite.subject.response.SubjectResponse;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubjectService {
	@Autowired
	private SubjectRepository subjectRepo;
	
	@Autowired
    private ModelMapper mapper;
 
    public SubjectResponse findsubjectByStudentId(Long id) {
        Optional<Subject> subjectBystdId = subjectRepo.findSubjectByStudentId(id);
        SubjectResponse addressResponse = mapper.map(subjectBystdId, SubjectResponse.class);
        return addressResponse;
    }

}
