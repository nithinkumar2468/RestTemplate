package com.infinite.product2.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinite.product2.model.Products2;
import com.infinite.product2.repository.Product2Repository;

@Service
public class Product2Service {
	@Autowired
	private Product2Repository prodRepo;
	

	public Products2 addProduct2(Products2 product2) {
		// TODO Auto-generated method stub
		return prodRepo.save(product2);
	}

	public List<Products2> getallproducts() {
		// TODO Auto-generated method stub
		return prodRepo.findAll();
	}
	
	/*
    public SubjectResponse findsubjectByStudentId(Long id) {
        Optional<Subject> subjectBystdId = subjectRepo.findSubjectByStudentId(id);
        SubjectResponse addressResponse = mapper.map(subjectBystdId, SubjectResponse.class);
        return addressResponse;
    }*/

	public Optional<Products2> getproductbyid(Long pid2) {
		// TODO Auto-generated method stub
		return prodRepo.findById(pid2);
	}

	public Optional<Products2> updateproductbyid(Products2 product, Long pid2) {
		// TODO Auto-generated method stub
		return prodRepo.findById(pid2).map(prod->{
			prod.setP_name(product.getP_name());
			prod.setP_rating(product.getP_rating());
			prod.setP_price(product.getP_price());
			return prodRepo.save(prod);
		});
	}

	public String deleteproductbyid(Long pid2) {
		// TODO Auto-generated method stub
		prodRepo.deleteById(pid2);
		return "Deleted Successfully";
	}

}
