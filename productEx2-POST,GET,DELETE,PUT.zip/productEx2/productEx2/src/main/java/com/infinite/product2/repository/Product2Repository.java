package com.infinite.product2.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.infinite.product2.model.Products2;
@Repository
public interface Product2Repository extends JpaRepository<Products2,Long> {
	@Query(
	        nativeQuery = true,
	        value
	        = "SELECT ea.pid2, ea.p_name, ea.p_rating,ea.p_price FROM tutorialdb.products2 ea join tutorialdb.products1 e ON ea.pid2=e.pid")
	       Optional<Products2> findAllProducts();

}
