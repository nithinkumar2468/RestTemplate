package com.infinite.product2.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.infinite.product2.model.Products2;
import com.infinite.product2.service.Product2Service;

@RestController
public class Product2Controller {

	@Autowired
	private Product2Service prodService;

	/*
	 * @PostMapping("/product2") public Products2 CreateProduct(@RequestBody
	 * Products2 product2) { return prodService.addProduct2(product2); }
	 */

	@PostMapping("/product2")
	private ResponseEntity<String> CreateProduct(@RequestBody Products2 product2) {
		prodService.addProduct2(product2);
		return new ResponseEntity<>("Product2 saved successfully", HttpStatus.CREATED);
	}

	/*
	 * @GetMapping("/products2") List<Products2> GetAllProducts2() { return
	 * prodService.getallproducts(); }
	 */

	@GetMapping("/products2")
	private ResponseEntity<List<Products2>> GetAllProducts2() {
		List<Products2> products2 = prodService.getallproducts();
		return new ResponseEntity<>(products2, HttpStatus.CREATED);
	}

	@GetMapping("/product2/{pid2}")
	public Optional<Products2> GetProduct2byId(@PathVariable Long pid2) {
		return prodService.getproductbyid(pid2);
	}

	@PutMapping("/product2/{pid2}")
	public Optional<Products2> UpdateProduct2byId(@RequestBody Products2 product, @PathVariable Long pid2) {
		return prodService.updateproductbyid(product, pid2);
	}

	@DeleteMapping("/product2/{pid2}")
	void DeleteProduct2byId(@PathVariable Long pid2) {
		prodService.deleteproductbyid(pid2);
	}

}