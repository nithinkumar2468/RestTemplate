package com.infinite.product2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductEx2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductEx2Application.class, args);
	}

}
